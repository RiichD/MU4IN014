README

----------Exercice 2, 3, 5 : Question 1
Les fichiers sont téléchargés grace à download.py

----------Exercice 3:

-----Q3:
Cette question possède beaucoup de données et nécessite probablement d'afficher les résultats dans un fichier au lieu de l'afficher sur le terminal.
La fonction get_for_each_film(file_path, fileFormat, fileName) possède une variable fileFormat :
	- Si elle vaut True, un fichier du nom de fileName est créé et les affichages se trouvent dans le fichier
	Par défaut, le fichier fileName se nomme film_data.txt 
	- Sinon False, tout est affiché sur le terminal.

----------Exercice 4:

Deux versions de cette exercice sont disponibles :

- An_HTML.py :
Cette version accède aux données se trouvant sur wikipédia à chaque fois.

- An_HTML_Local.py :
Cette version télécharge les données se trouvant sur wikipédia et les accès aux données se font sur les données téléchargées.
Il faut créer un dossier links et un dossier links/wiki avant le téléchargement.

Le fichier result.txt contient les affichages.

-----Q4:
taper 'exit' pour quitter